__version__ = '2.0'
__author__ = 'RJ White'

__all__ = [ '__version__', '__author__' ]
