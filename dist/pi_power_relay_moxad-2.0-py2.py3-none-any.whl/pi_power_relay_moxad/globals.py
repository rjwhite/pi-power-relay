debug_flag = False
progname   = None
